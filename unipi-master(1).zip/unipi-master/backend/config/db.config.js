module.exports = {
    HOST: "localhost",
    PORT: "1433",
    USER: "sa",
    PASSWORD: "sasasa",
    DB: "modbus",
    dialect: "mssql",
    dialectOptions: {
        requestTimeout: 30000,
        encrypt: true
    },
    options:{
        "enableArithAbort": true,
    },
    pool: {
      max: 10,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  };