const verify = require('../utility/validation')

module.exports = app => {
    const Model = require("../controllers/auth");
    var router = require("express").Router();

    //LOGIN
    router.post("/login", Model.login);
    app.use('/api/auth', router);
};