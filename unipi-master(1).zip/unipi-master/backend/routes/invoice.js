const verify = require('../utility/verifyToken')

module.exports = app => {
    const Model = require("../controllers/invoice.js");
    var router = require("express").Router();

    // Retrieve all data
    router.get("/", Model.findAll);
    router.post("/", Model.create);
    router.put("/:id", Model.update);
    router.delete("/:id", Model.delete);

    // Retrieve all data
    router.get("/item/:id", Model.findItem)
    router.post("/item", Model.createDetail)
    router.put("/item/:id", Model.updateItem);
    router.delete("/item/:id", Model.deleteItem)

    app.use('/api/invoice', router);
};