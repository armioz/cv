const verify = require('../utility/verifyToken')

module.exports = app => {
    const Model = require("../controllers/modbus.js");
  
    var router = require("express").Router();
  
    // Retrieve all data
    router.get("/", Model.findAll);

    router.post("/", Model.create);

    router.put("/:id", Model.update);

    router.delete("/:id", Model.delete);

    app.use('/api/modbus', router);
  };