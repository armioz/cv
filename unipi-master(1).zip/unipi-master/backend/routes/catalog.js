const verify = require('../utility/verifyToken')

module.exports = app => {
    const Model = require("../controllers/catalog")
    var router = require("express").Router();
    //USER
    //create New User
    router.post("/", verify, Model.create);
    //get data All User
    router.get("/", verify, Model.findAll);
    //get data User
    router.get("/:id", verify, Model.findOne);
    //update data User
    router.put("/:id", verify, Model.update);
    //delete user
    router.delete("/:id", verify, Model.delete);

    app.use('/api/catalog', router);
};