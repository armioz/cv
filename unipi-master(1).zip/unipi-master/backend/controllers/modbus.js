const db = require("../models");
const { modbusValidation } = require('../utility/validation')

const { Modbus } = db;
const Op = db.Sequelize.Op;

exports.create = async (req, res) => {
    const body = req.body;
    // Validate the data
    const { error } = modbusValidation(body);
    if (error) return res.status(400).send(error.details[0].message)

    // Create a Variable
    const dataToCreate = {
        ip_address: String(body.ip_address),
        port: String(body.port),
        unitid: String(body.unitid),
        valvePosition: Number(body.valvePosition),
        powerKW: Number(body.powerKW),
        Temp1C: Number(body.Temp1C),
        Temp1K: Number(body.Temp1K),
        Temp2C: Number(body.Temp2C),
        Temp2K: Number(body.Temp2K),
        Temp1W: Number(body.Temp1W),
    };

    // console.log("dataToCreate", dataToCreate);

    // Save Modbus data in the database
    try {
        const result = await Modbus.create(dataToCreate)
        res.send(result);
    } catch (err) {
        res.status(400).send({ message: err.parent.message })
    }
};

exports.update = async (req, res) => {
    const id = req.params.id
    const body = req.body

    //Validate data
    const { error } = modbusValidation(body)
    if (error) return res.status(400).send(error.details[0].message)

    try {
        const updated = await Modbus.update(body, { where: { id: id } })
        if (updated) {
            res.send({ message: "Updated a modbus" })
        }
        else {
            res.status(400).send({ message: "Cannot update a modbus" })
        }
    } catch (error) {
        res.status(400).send(error)
    }
};

exports.findAll = async (req, res) => {
    try {
        const modbus = await Modbus.findAll()
        res.send(modbus)
    } catch (err) {
        res.status(500).send(err);
    }
};

exports.delete = async (req, res) => {
    const id = req.params.id;
    // console.log(id);

    try {
        const deleted = await Modbus.destroy({ where: { id: id } })
        if (deleted) {
            res.send({ message: "Deletes a Modbus" })
        }
        else {
            res.status(400).send({ message: "Cannot delete a Modbus" })
        }
    } catch (error) {
        res.status(400).send({ message: error })
    }
};
