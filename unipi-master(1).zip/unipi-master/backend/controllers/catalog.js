const db = require("../models");
const { catalogValidation } = require('../utility/validation')
const moment = require('moment')

const { Catalog } = db;
const Op = db.Sequelize.Op;

const ModelName = 'catalogs'

//USER
exports.create = async (req, res) => {
    const body = req.body;
    // Validate the data
    console.log(body);
    
    const { error } = catalogValidation(body);
    if(error) return res.status(400).send(error.details[0].message)

    // Save a new User in the database
    try {
        const result = await Catalog.create(body)
        res.send(format(result));
    } catch (err) {
        res.status(400).send({message: err.parent.message})
    }
};

exports.findOne = async(req, res) => {
    //Checking req has username
    const { id } = req.params
    if(!id) return res.status(400).send("Request don't has id")
    // console.log(username);
    
    try {
        const result = await Catalog.findOne({ where: { id: id } })
        if(result !== null){
            res.send(format(result))
        }
        else{
            res.status(400).send(id + " has not already exists")
        }
        // console.log(user);
        
    } catch (err) {
        res.status(500).send(err)
    }
};

exports.findAll = async(req, res) => {
    try {
        const result = await Catalog.findAll()
        res.send(result.map(re => format(re)))
    } catch (err) {
        res.status(500).send(err);
    }
};

exports.update = async(req, res) => {

    const id = req.params.id
    const body = req.body
    
    //Validate data
    const { error } = catalogValidation(body)
    if(error) return res.status(400).send(error.details[0].message)

    try {
        const updated = await Catalog.update(body, { where: { id: id } })
        if(updated){
            res.send({message: `Updated a ${ModelName} success`})
        }
        else{
            res.status(400).send({message: `Cannot update a ${ModelName} fail`})
        }
    } catch (error) {
        res.status(400).send(error)
    }
};

exports.delete = async(req, res) => {
    const id = req.params.id;

    try {
        const deleted = await Catalog.destroy({ where: { id: id } })
        if(deleted){
            res.send({message: `Deletes a ${ModelName} success`})
        }
        else{
            res.status(400).send({message: `Cannot deletes a ${ModelName} fail`})
        }
    } catch (error) {
        res.status(400).send({message: error})
    }
};

const format = (data) => {
    return { 
        id: data.id,
        name: data.name,
        price: data.price
    }
}