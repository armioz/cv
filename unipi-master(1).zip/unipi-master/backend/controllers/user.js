const db = require("../models");
const bcrypt = require('bcryptjs')
const { registerValidation, updateUserValidation } = require('../utility/validation')
const moment = require('moment')

const { User, Log } = db
const Op = db.Sequelize.Op;

//USER
exports.create = async (req, res) => {
    const body = req.body;
    // Validate the data
    const { error } = registerValidation(body);
    if(error) return res.status(400).send(error.details[0].message)

    // Checking user is already exists in DB
    const usernameExist = await User.findOne({ where: {username: body.username}})
    if(usernameExist) return res.status(400).send("Username already exists")

    //Hash password
    const salt = await bcrypt.genSalt(10)
    const hashPassword = await bcrypt.hash(req.body.password, salt)

    // Create a Variable
    const dataToCreate = {
        username: String(body.username) ,
        password: String(hashPassword) ,
        role: String(body.role)
    };
    console.log("dataToCreate", dataToCreate);

    // Save a new User in the database
    try {
        const result = await User.create(dataToCreate)
        res.send(formatUser(result));
    } catch (err) {
        res.status(400).send({messdsage: err.parent.message})
    }
};

exports.findOne = async(req, res) => {
    //Checking req has username
    const { id } = req.params
    if(!id) return res.status(400).send("Request don't has id")
    // console.log(username);
    
    try {
        const result = await User.findOne({ where: { id: id } })
        if(result !== null){
            res.send(formatUser(result))
        }
        else{
            res.status(400).send(id + " has not already exists")
        }
        // console.log(user);
        
    } catch (err) {
        res.status(500).send(err)
    }
};

exports.findAll = async(req, res) => {
    try {
        const users = await User.findAll()
        res.send(users.map( v => formatUser(v)))
    } catch (err) {
        res.status(500).send(err);
    }
};

exports.update = async(req, res) => {

    const id = req.params.id
    const body = req.body
    
    //Validate data
    const { error } = updateUserValidation(body)
    if(error) return res.status(400).send(error.details[0].message)

    if(body.password){
        const salt = await bcrypt.genSalt(10)
        body.password = await bcrypt.hash(body.password, salt)
    }

    try {
        const updated = await User.update(body, { where: { id: id } })
        if(updated){
            res.send({message: "Updated a user"})
        }
        else{
            res.status(400).send({message: "Cannot update a user"})
        }
    } catch (error) {
        res.status(400).send(error)
    }
};

exports.delete = async(req, res) => {
    const id = req.params.id;

    try {
        const deleted = await User.destroy({ where: { id: id } })
        await Log.destroy({ where: { id: id } })

        if(deleted){
            res.send({message: "Deletes a user"})
        }
        else{
            res.status(400).send({message: "Cannot delete a user"})
        }
    } catch (error) {
        res.status(400).send({messdsage: error.parent.message})
    }
};

// Log
exports.findLogsUser = async(req, res) => {
    //Checking req has id
    const { id } = req.params
    if(!id) return res.status(400).send("Request don't has id")
    // console.log(username);
    
    try {
        const logs = await Log.findAll({ where: { userId: id } })//
        // console.log(logs);
        if(logs !== null){
            const format = logs.map(v => formatLog(v.dataValues))
            res.send(format)
        }
        else{
            res.status(400).send(id + " has not already exists")
        }
        // console.log(user);
    } catch (err) {
        res.status(500).send(err)
    }
};


const formatUser = (user) => {
    return { 
        id: user.id,
        username: user.username,
        role: user.role,
        createdAt: moment(user.createdAt).format('MM/DD/YYYY hh:mm:ss'),
    }
}

const formatLog = (log) => {
    return { 
        id: log.id,
        userId: log.userId,
        time:  moment(log.createdAt).format('MM/DD/YYYY hh:mm:ss'),
    }
}