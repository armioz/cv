const db = require("../models")
const { contactValidation } = require('../utility/validation')
const moment = require('moment')

const { Contact } = db;
const Op = db.Sequelize.Op;

const conName = 'contact'

//USER
exports.create = async (req, res) => {
    const body = req.body;
    // Validate the data
    const { error } = contactValidation(body);
    if(error) return res.status(400).send(error.details[0].message)

    // Save a new User in the database
    try {
        const result = await Contact.create(body)
        res.send(format(result));
    } catch (err) {
        res.status(400).send({message: err.parent.message})
    }
};

exports.findOne = async(req, res) => {
    //Checking req has username
    const { id } = req.params
    if(!id) return res.status(400).send("Request don't has id")
    // console.log(username);
    
    try {
        const result = await Contact.findOne({ where: { id: id } })
        if(result !== null){
            res.send(format(result))
        }
        else{
            res.status(400).send(id + " has not already exists")
        }
        // console.log(user);
        
    } catch (err) {
        res.status(500).send(err)
    }
};

exports.findAll = async(req, res) => {
    try {
        const result = await Contact.findAll()
        res.send(result.map(re => format(re)))
    } catch (err) {
        res.status(500).send(err);
    }
};

exports.update = async(req, res) => {

    const id = req.params.id
    const body = req.body
    
    //Validate data
    const { error } = contactValidation(body)
    if(error) return res.status(400).send(error.details[0].message)
    // Create a Variable

    try {
        const updated = await Contact.update(body, { where: { id: id } })
        if(updated){
            res.send({message: `Updated a ${conName} success`})
        }
        else{
            res.status(400).send({message: `Cannot update a ${conName} fail`})
        }
    } catch (error) {
        res.status(500).send(error)
    }
};

exports.delete = async(req, res) => {
    const id = req.params.id;

    try {
        const deleted = await Contact.destroy({ where: { id: id } })
        if(deleted){
            res.send({message: `Deletes a ${conName} success`})
        }
        else{
            res.status(400).send({message: `Cannot deletes a ${conName} fail`})
        }
    } catch (error) {
        res.status(400).send({message: error.parent.message})
    }
}

const format = (data) => {
    return { 
        id: data.id,
        customer_name: data.customer_name,
        address: data.address
    }
}