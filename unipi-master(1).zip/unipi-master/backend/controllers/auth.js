const db = require("../models");
const jwt = require("jsonwebtoken")
const bcrypt = require('bcryptjs')
const { loginValidation } = require('../utility/validation')

const { User, Log } = db
const Op = db.Sequelize.Op;

//Login
exports.login = async (req, res) => {
    const body = req.body;
    // Validate the data
    const { error } = loginValidation(body);
    if(error) return res.status(400).send(error.details[0].message)

    // Checking user is already exists in DB
    const user = await User.findOne({ where: {username: body.username}})
    if(!user) return res.status(400).send("Username or password is wrong")
    
    // console.log(body.password, user.dataValues.password);
    
    //Password IS CORRECT
    const validPass = await bcrypt.compare(body.password, user.dataValues.password)
    if(!validPass) return res.status(400).send("Invalid password")

    const token = generateAccessToken({id: user.dataValues.id})

    await Log.create({userId: user.dataValues.id})
    res.send({user: {id: user.dataValues.id, username: user.dataValues.username, role: user.dataValues.role},token: token})
}

let generateAccessToken = (user) => {
    return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET)
}
