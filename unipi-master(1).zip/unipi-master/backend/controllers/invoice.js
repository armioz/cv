const db = require("../models");
const { invoiceValidation, detialValidation } = require('../utility/validation')
const moment = require('moment')

const { Invoice, Contact, InvoiceItem, Catalog } = db
const ModelName = 'invoices'

exports.create = async (req, res) => {
    const body = req.body;
    // Validate the data
    // console.log(body);
    const { error } = invoiceValidation(body);
    if(error) return res.status(400).send(error.details[0].message)

    const contact = await Contact.findOne({where: {id: body.contactId}})
    if(!contact) return res.status(400).send("Contact has not already exists")
    // res.send(contact)

    // Save a new User in the database
    try {
        const result = await Invoice.create(body)
        res.send(format(result));
    } catch (err) {
        res.status(400).send({message: err.parent.message})
    }
};

exports.findAll = async(req, res) => {
    try {
        const data = await Invoice.findAll({include: [Contact]})
        res.send(data.map( v => formatInvoice(v)))
    } catch (err) {
        res.status(500).send(err);
    }
};

exports.update = async(req, res) => {

    const id = req.params.id
    const body = req.body
    
    //Validate data
    const { error } = invoiceValidation(body)
    if(error) return res.status(400).send(error.details[0].message)

    const contact = await Contact.findOne({where: {id: body.contactId}})
    if(!contact) return res.status(400).send("Contact has not already exists")
    
    try {
        const updated = await Invoice.update(body, { where: { id: id } })
        if(updated){
            res.send({message: `Updated a ${ModelName} success`})
        }
        else{
            res.status(400).send({message: `Cannot update a ${ModelName} fail`})
        }
    } catch (error) {
        res.status(400).send(error)
    }
};

exports.delete = async(req, res) => {
    const id = req.params.id;

    try {
        const deleted = await Invoice.destroy({ where: { id: id } })
        if(deleted){
            res.send({message: `Deletes a ${ModelName} success`})
        }
        else{
            res.status(400).send({message: `Cannot deletes a ${ModelName} fail`})
        }
    } catch (error) {
        res.status(400).send({message: error.parent.message})
    }
}

const formatInvoice = data => {
    return {
        invoiceId: data.id,
        status: data.status,
        total: data.total,
        contactId: data.contact.id,
        customer_name: data.contact.customer_name,
        address: data.contact.address
    }
}

const format = (data) => {
    return { 
        id: data.id,
    }
}

exports.createDetail = async (req, res) => {
    const body = req.body;
    // Validate the data
    // console.log(body);
    const { error } = detialValidation(body);
    if(error) return res.status(400).send(error.details[0].message)

    // Save a new User in the database
    try {
        const result = await InvoiceItem.create(body)
        res.send(result);
    } catch (err) {
        res.status(400).send({message: err.parent.message})
    }
};

exports.findItem = async(req, res) => {
    let id = req.params.id
    
    try {
        const data = await InvoiceItem.findAll({where: {invoiceId: id}, include: [Catalog]})
        res.send(data.map( v => formatItem(v)))
    } catch (err) {
        res.status(500).send(err);
    }
};

exports.deleteItem = async(req, res) => {
    const id = req.params.id;

    try {
        const deleted = await InvoiceItem.destroy({ where: { id: id } })
        if(deleted){
            res.send({message: `Deletes a item success`})
        }
        else{
            res.status(400).send({message: `Cannot deletes a item fail`})
        }
    } catch (error) {
        res.status(400).send({message: error.parent.message})
    }
}

exports.updateItem = async(req, res) => {

    const id = req.params.id
    const body = req.body
    
    try {
        const updated = await InvoiceItem.update(body, { where: { id: id } })
        if(updated){
            res.send({message: `Updated a ${ModelName} item success`})
        }
        else{
            res.status(400).send({message: `Cannot update a ${ModelName} item fail`})
        }
    } catch (error) {
        res.status(400).send(error)
    }
};

const formatItem = data => {
    return {
        id: data.id,
        quantity: data.quantity,
        catalogId: data.catalogId,
        invoiceId: data.invoiceId,
        name: data.catalog.name,
        price: data.catalog.price,
    }
}
    