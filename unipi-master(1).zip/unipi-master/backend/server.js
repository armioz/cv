const express = require('express');
const cors = require('cors');

require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*')
    res.header('Access-Control-Allow-Methods','POST, GET, PUT, PATCH, DELETE, OPTIONS')
    res.header('Access-Control-Allow-Headers','Content-Type, Option, Authorization')
    return next()
})

const db = require("./models");
db.sequelize.sync();
// db.sequelize.sync({ force: true }).then(() => {
//     console.log("Drop and re-sync db.");
// });

require("./routes/auth")(app);
require("./routes/user")(app);
require("./routes/contact")(app);
require("./routes/modbus")(app);
require("./routes/catalog")(app);
require("./routes/invoice")(app);


app.listen(port, ()=>{
    console.log(`Server is running on port: ${port}`);
});
