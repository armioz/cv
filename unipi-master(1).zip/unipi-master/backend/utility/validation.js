const Joi = require('@hapi/joi')

exports.loginValidation = data => {
    const schema = Joi.object({
        username: Joi.string()
                    .min(3)
                    .required(),
        password: Joi.string()
                    .min(3)
                    .required()
    })
    return schema.validate(data)
}

exports.registerValidation = data => {
    const schema =  Joi.object({
        username: Joi.string()
                    .min(3)
                    .required(),
        password: Joi.string()
                    .min(3)
                    .required(),
        role: Joi.string()
                .required()
    })
    return schema.validate(data)
}

exports.modbusValidation = data => {
    const schema = Joi.object({
        ip_address: Joi.string().required(),
        port: Joi.string().required(),       
        unitid: Joi.string().required(),        
        valvePosition: Joi.number().required(),
        powerKW: Joi.number().required(),
        Temp1C: Joi.number().required(),
        Temp1K: Joi.number().required(),
        Temp2C: Joi.number().required(),
        Temp2K: Joi.number().required(),
        Temp1W: Joi.number().required(),
    })
    return schema.validate(data)
}

exports.updateUserValidation = data => {
    const schema =  Joi.object({
        username: Joi.string()
                    .min(3)
                    .required(),
        password: Joi.string()
                    .min(3),
        role: Joi.string()
                .required()
    })
    return schema.validate(data)
}

exports.contactValidation = data => {
    const schema =  Joi.object({
        customer_name: Joi.string()
                    .min(3)
                    .required(),
        address: Joi.string()
                    .min(3)
                    .required(),
    })
    return schema.validate(data)
}

exports.catalogValidation = data => {
    const schema =  Joi.object({
        name: Joi.string()
                .required(),
        price: Joi.number()
                .required(),
    })
    return schema.validate(data)
}

exports.invoiceValidation = data => {
    const schema =  Joi.object({
        status: Joi.string()
                .required(),
        total: Joi.number()
                .required(),
        contactId: Joi.number()
                .required(),
    })
    return schema.validate(data)
}

exports.detialValidation = data => {
    const schema =  Joi.object({
        invoiceId: Joi.number()
                .required(),
        quantity: Joi.number()
                .required(),
        catalogId: Joi.number()
                .required(),
    })
    return schema.validate(data)
}