const dbConfig = require("../config/db.config.js");

const Sequelize = require("sequelize");
const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
    host: dbConfig.HOST,
    port: dbConfig.PORT,
    dialect: dbConfig.dialect,
    //   dialectOptions: dbConfig.dialectOptions,
    operatorsAliases: false,
    options: dbConfig.option,
    pool: {
        max: dbConfig.pool.max,
        min: dbConfig.pool.min,
        acquire: dbConfig.pool.acquire,
        idle: dbConfig.pool.idle
    }
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.Modbus = require("./modbus.model.js")(sequelize, Sequelize);
db.User = require("./users.model.js")(sequelize, Sequelize);
db.Log = require("./logUser.model.js")(sequelize, Sequelize);
db.Contact = require("./contact.model.js")(sequelize, Sequelize);
db.Catalog = require("./catalog.model.js")(sequelize, Sequelize);
db.Invoice = require("./invoice.model.js")(sequelize, Sequelize);
db.InvoiceItem = require("./invoiceItem.model.js")(sequelize, Sequelize);

db.Log.belongsTo(db.User)
db.Invoice.belongsTo(db.Contact)
db.InvoiceItem.belongsTo(db.Catalog)
db.InvoiceItem.belongsTo(db.Invoice)

module.exports = db;