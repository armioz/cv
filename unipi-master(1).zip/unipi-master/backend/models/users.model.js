module.exports = (sequelize, Sequelize) => {
    const Model = sequelize.define("users", {
        username: {
            type: Sequelize.STRING
        },
        password: {
            type: Sequelize.STRING
        },
        role: {
            type: Sequelize.ENUM,
            values: ['user', 'admin', 'disabled'],
            defaultValue: 'user'
        }
    },
    {
        createdAt: "createdAt",
        updatedAt: "updatedAt",
        freezeTableName: true,
        indexes: [
            {
                unique: true,
                fields: ['username']
            }
        ]
    });

    return Model;
};

/*
create a new Tutorial: create(object)
find a Tutorial by id: findByPk(id)
get all Tutorials: findAll()
update a Tutorial by id: update(data, where: { id: id })
remove a Tutorial: destroy(where: { id: id })
remove all Tutorials: destroy(where: {})
find all Tutorials by title: findAll({ where: { title: ... } })
*/