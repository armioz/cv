module.exports = (sequelize, Sequelize) => {
    const Model = sequelize.define("catalog", {
        name: {
            type: Sequelize.STRING
        },
        price: {
            type: Sequelize.INTEGER
        },
    },
        {
            createdAt: "createdAt",
            updatedAt: "updatedAt",
            freezeTableName: true,
            indexes: [
                {
                    unique: true,
                    fields: ['name']
                }
            ]
        });

    return Model;
};
