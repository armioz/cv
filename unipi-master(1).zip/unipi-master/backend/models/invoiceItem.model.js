module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define("invoiceItem", {
        quantity: {
            type: DataTypes.INTEGER,
        }
    },
        {
            createdAt: "createdAt",
            updatedAt: "updatedAt",
            freezeTableName: true,
        });

    return Model;
};
