module.exports = (sequelize, Sequelize) => {
    const Model = sequelize.define("contact", {
        customer_name: {
            type: Sequelize.STRING
        },
        address: {
            type: Sequelize.STRING
        },
    },
        {
            createdAt: "createdAt",
            updatedAt: "updatedAt",
            freezeTableName: true,
        });

    return Model;
};
