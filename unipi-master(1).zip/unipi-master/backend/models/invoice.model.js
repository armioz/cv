module.exports = (sequelize, Sequelize) => {
    const Model = sequelize.define("invoice", {
        status: {
            type: Sequelize.ENUM,
            values: ['Paid', 'Unpaid', 'Open'],
            defaultValue: 'Open'
        },
        total: {
            type: Sequelize.INTEGER
        },
    },
        {
            createdAt: "createdAt",
            updatedAt: "updatedAt",
            freezeTableName: true,
        });

    return Model;
};
