module.exports = (sequelize, Sequelize) => {
    const Model = sequelize.define("modbus", {
      ip_address: {
        type: Sequelize.STRING
      },
      port: {
        type: Sequelize.STRING
      },
      unitid: {
        type: Sequelize.STRING
      },
      valvePosition: {
        type: Sequelize.INTEGER
      },
      powerKW: {
        type: Sequelize.INTEGER
      },
      Temp1C: {
        type: Sequelize.INTEGER
      },
      Temp1K: {
        type: Sequelize.INTEGER
      },
      Temp2C: {
        type: Sequelize.INTEGER
      },
      Temp2K: {
        type: Sequelize.INTEGER
      },
      Temp1W: {
        type: Sequelize.INTEGER
      },
    },
    {
        createdAt: "timeStamp",
        updatedAt: false,
        freezeTableName: true
    }
    );
  
    return Model;
  };

  /*
create a new Tutorial: create(object)
find a Tutorial by id: findByPk(id)
get all Tutorials: findAll()
update a Tutorial by id: update(data, where: { id: id })
remove a Tutorial: destroy(where: { id: id })
remove all Tutorials: destroy(where: {})
find all Tutorials by title: findAll({ where: { title: ... } })
*/