<template>
    <v-data-table
        :headers="headers"
        :items="items"
        :search="search"
        class="elevation-1"
        >
        <template v-slot:top>
            <Confirm :submit="deleteConfirm"></Confirm>
            <v-toolbar flat color="white">
                <v-toolbar-title class="headline font-weight-bold">{{name}}</v-toolbar-title>
                <v-divider class="mx-4" inset vertical></v-divider>
                <v-spacer></v-spacer>
                <Header
                    :name="name.toLowerCase()"
                    :resValue="save"
                    :defaultForm="$store.state.invoice.form"
                    :defaultValue="$store.state.invoice.valueDefault"
                    >
                </Header>
            </v-toolbar>
            <v-text-field
                solo 
                v-model="search" 
                label="Search" 
                class="mx-5" 
                hide-details
                >
            </v-text-field>
        </template>
        <template v-slot:body="{ items }">
            <tbody class="mt-5">
                <tr v-for="(item, i) in items" :key="i" :style="items.indexOf(item) % 2 ?  '' : 'background: #BDBDBD'">
                    <td @click="showDetail(item)">{{ item.invoiceId }}</td>
                    <td @click="showDetail(item)">{{ item.customer_name }}</td>
                    <td @click="showDetail(item)">{{ item.address }}</td>
                    <td @click="showDetail(item)">{{ item.status }}</td>
                    <td @click="showDetail(item)">{{ item.total }}</td>
                    <td> 
                        <v-icon small class="mr-2" @click="editItem(item)">
                            mdi-pencil
                        </v-icon>
                        <v-icon small @click="Confirm(item)">
                            mdi-delete
                        </v-icon>
                    </td>
                </tr>
            </tbody>
        </template>
    </v-data-table>
</template>

<script>
import { mapActions } from 'vuex'

export default {
    name: 'invoiceHeader',
    components: {
        Header: () => import('@/components/utility/FormDialog'),
        Confirm: () => import('@/components/utility/ConfirmDialog')
    },
    data() {
        return {
            search: '',
            deleteItem: null
        }
    },
    computed: {
    },
    methods: {
        ...mapActions('invoice', ['create', 'update']),
        showDetail(item) {
            // console.log(item);
            this.$store.dispatch('invoice/getInvoiceItem', item)
        },
        async save ({ action, value }) {
            // console.log(action, value);
             //Set loading btn
            this.$store.commit('dialog/LOADING', true)
            // //Set hide Alert
            this.$store.commit('dialog/ALERT_CHANGE', { show: false })
            // //Set index and call store
            let index = this.$store.state.dialog.editIndex
            const {success, text} = action == 'new' ? await this.create(value) : await this.update({index, value})
            //Stop loading
            this.$store.commit('dialog/LOADING', false)
            //Set alert show
            if(success) { 
                await this.$store.commit('dialog/ALERT_CHANGE', { type: 'success', text, show: true }) 
                if(action === 'new') this.$store.commit('dialog/CHANGE_DIALOG', {name: this.name, value: false} )
            }
            else{ this.$store.commit('dialog/ALERT_CHANGE',  { type: 'error', text: text, show: true }) }
            // console.log(success, text)
        },
        editItem (item) {
            // Set index of item
            const index = this.items.indexOf(item)
            // console.log(item);
            //Send to store index, item
            this.$store.commit('dialog/EDIT_ITEM', { index, item })
            //Open dialog
            this.$store.commit('dialog/CHANGE_DIALOG',  {name: this.name, value: true})
        },
        Confirm (item) {
            // console.log("open confirm");
            //Set delete item
            this.deleteItem = item
            //Show Dialog hode Alert
            this.$store.commit('dialog/ALERT_CHANGE',  { show: false })
            this.$store.commit('confirm/CHANGE_DIALOG', {showing: true, title: "Delete", text: "Are you sure to delete item",})
        },
        async deleteConfirm(value) {
            // Select close diolog or next to delete 
            value === false ? this.$store.commit('confirm/CHANGE_DIALOG', {showing: false}) : this.$store.commit('confirm/LOADING')
            // if Close dialog return
            if(!value){return}
            // Deleting
            let {success, text} = await this.$store.dispatch("invoice/delete", this.deleteItem)
            // if error show alert
            if(!success) {this.$store.commit('dialog/ALERT_CHANGE',  { type: 'error', text: text, show: true }); return}
            // if success show alert and close dialog
            this.$store.commit('dialog/ALERT_CHANGE',  { type: 'success', text: text, show: true })
            this.$store.commit('confirm/CHANGE_DIALOG', {showing: false})
            // console.log(success, text);
        }
    },
    props: ['headers', 'items', 'name']
}
</script>

<style>

</style>