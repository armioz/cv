<template>
    <v-dialog v-model="dialog" persistent max-width="500px">
        <template v-slot:activator="{ on }">
            <v-btn color="primary" dark class="mb-2" v-on="on">New {{ name }}</v-btn>
        </template>
        <v-card>
        <v-card-title>
            <span class="headline">{{ dialogTitle }}</span>
        </v-card-title>
        <v-card-text>
            <v-form v-model="validForm" ref="userForm">
                <v-text-field 
                    v-model="value[username.value]"
                    :label="username.label"
                    :rules="username.rules"
                    :disabled="username.disabled ? username.disabled : false"
                    :counter="username.counter || false"
                ></v-text-field>
                <v-text-field
                    v-model="value.password"
                    :counter="password.counter || false"
                    :type="showPassword ? 'text' : 'password'"
                    :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                    @click:append="showPassword = !showPassword"
                    :label="password.label"
                    :rules="password.rules"
                ></v-text-field>
                <v-text-field
                    v-if="hasPass2"
                    v-model="value.password2"
                    :counter="password2.counter || false"
                    type='password'
                    hide-detail="auto"
                    :label="password2.label"
                    :rules="password2.rules"
                ></v-text-field>
                <v-select
                    v-model="value.role"
                    :label="role.label"
                    :items="role.items"
                    :rules="role.rules"
                ></v-select>
                <v-alert v-show="$store.state.dialog.alert.show" :type="$store.state.dialog.alert.type">
                    {{ $store.state.dialog.alert.text }}
                </v-alert>
                <v-row justify="end">
                    <v-col cols='4' sm='3'>
                        <v-btn color="error" @click="close">Cancel</v-btn>
                    </v-col>
                    <v-col cols='4' sm='3'>
                        <v-btn 
                            color="primary" 
                            @click="submit(value)" 
                            :disabled="!validForm"
                            :loading="loading"
                            >
                            Save
                        </v-btn>
                    </v-col>
                </v-row>
            </v-form>
        </v-card-text>
        </v-card>
    </v-dialog>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: "userForm",
    data() {
        return {
            showPassword: false,
            validForm: false,
            value: {
                username: "",
                password: "",
                password2: "",
                role: "",
            },
            username: {
                label: "Username",
                value: 'username',
                rules : [
                    v => !!v || "Username is required", 
                    v => (v && v.length <= 25) || "Username must be less than 25 characters",
                    v => (v && v.length >= 3) || "Username must be more than 3 characters"
                ],
                counter: 25
            }, 
            password: {
                label: "Password",
                value: 'password',
                rules : [
                    v => !!v || "Password is required", 
                    v => (v && v.length <= 25) || "Password must be less than 25 characters",
                    v => (v && v.length >= 3) || "Password must be more than 3 characters"
                ],
                counter: 25,
            }, 
            password2: {
                label: "Confirm",
                value: 'password2',
                rules : [() => (this.value.password === this.value.password2) || 'Password must match'],
                counter: 25,
            }, 
            role: {
                label: "Role",
                value: 'role',
                items: ['admin', 'user'],
                rules : [ v => !!v || "Role is required", ],
                counter: 25,
            }, 
        }
    },
    computed: {
        ...mapGetters('dialog', ['dialogTitle', 'isEdit']),
        
        dialog: {
            get: function () { return this.$store.state.dialog.status[this.name]},
            set: function (value) {
                this.$store.commit('dialog/CHANGE_DIALOG',  {name: this.name, value: value})
            }
        },
    },
    watch: {
        dialog (value) {
            if(!value) {
                this.$refs.userForm.reset()
                this.$refs.userForm.resetValidation()
            }
            if(this.isEdit > -1){
                let item = this.$store.state.dialog.editItem
                Object.assign(this.value, {
                    username: item.username,
                    password: "",
                    role: item.role,
                })
                this.password.rules =  []
            }
            else {
                this.password.rules = [
                    v => !!v || "Password is required", 
                    v => (v && v.length <= 25) || "Password must be less than 25 characters",
                    v => (v && v.length >= 3) || "Password must be more than 3 characters"
                ]
            }
            this.$store.commit('dialog/ALERT_CHANGE', { show: false })
        },
        'value.password': function(value) {
                // console.log(value)
                let index = this.$store.state.dialog.editIndex
                // console.log(index)

                if(index > -1 && value.length > 0){
                    this.password.rules =  [
                        v => (v && v.length <= 25) || "Password must be less than 25 characters",
                        v => (v && v.length >= 3) || "Password must be more than 3 characters"
                    ]
                } 
                else if (index > -1 && value.length === 0) {
                    this.password.rules =  []
                } 
                else {
                    this.password.rules = [
                        v => !!v || "Password is required", 
                        v => (v && v.length <= 25) || "Password must be less than 25 characters",
                        v => (v && v.length >= 3) || "Password must be more than 3 characters"
                    ]
            }
        }
    },
    methods: {
        close () {
            this.$store.commit('dialog/CHANGE_DIALOG', {name: this.name, value: false})
        },
        submit(value) {
            // console.log(value);
            this.$refs.userForm.resetValidation()
            value = Object.entries(value).filter(v => value[v[0]]).reduce((o, key) => ({...o, [key[0]]: key[1]}), {})
            const action = this.isEdit ? 'edit' : 'new'
            this.resValue({ action, value })
        }
    },
    props: ['name', 'hasPass2', 'resValue', 'loading']
}
</script>

<style>

</style>