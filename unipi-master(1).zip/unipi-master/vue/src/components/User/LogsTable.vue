<template>
    <v-data-table
        :headers="headers"
        :items="items"
        :search="search"
        class="elevation-1"
    >
        <template v-slot:top>
            <v-toolbar flat color="white">
                <v-toolbar-title class="headline font-weight-bold">{{name}}</v-toolbar-title>
                <v-divider class="mx-4" inset vertical></v-divider>
                <v-spacer></v-spacer>
            </v-toolbar>
            <v-text-field
                solo 
                v-model="search" 
                label="Search" 
                class="mx-5" 
                hide-details
                >
            </v-text-field>
        </template>
        <template v-slot:body="{ items }">
            <tbody class="mt-5">
                <tr v-for="(item, i) in items" :key="i" :style="items.indexOf(item) % 2 ?  '' : 'background: #BDBDBD'" @click="openLogs(item)">
                    <td>{{ item.id }}</td>
                    <td>{{ item.username }}</td>
                    <td>{{ item.time }}</td>
                </tr>
            </tbody>
        </template>
    </v-data-table>
</template>

<script>
export default {
    name:'logsTable',
    props: ['headers', 'items', 'name'],
    data() {
        return {
            search: '',
        }
    },
}
</script>

<style>

</style>