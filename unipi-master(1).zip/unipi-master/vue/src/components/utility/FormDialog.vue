<template>
    <v-dialog v-model="dialog" persistent max-width="500px">
        <template v-slot:activator="{ on }">
            <v-btn color="primary" dark class="mb-2" v-on="on">New {{ name }}</v-btn>
        </template>
        <v-card>
        <v-card-title>
            <span class="headline">{{ dialogTitle }} {{ name }}</span>
        </v-card-title>
        <v-card-text>
            <v-form v-model="validForm" ref="from">
                <div v-for="(input, i) in form" :key="i">
                    <v-text-field 
                        v-if=" input.type === 'text' || input.type === 'number'" 
                        v-model=" value[input.value] "
                        :label=" input.label "
                        :rules=" input.rules "
                        :disabled=" input.disabled ? input.disabled : false "
                        :counter=" input.counter || false "
                        :type=" input.type "
                    ></v-text-field>
                    <v-textarea
                        v-if=" input.type === 'textarea' " 
                        v-model=" value[input.value]"
                        :counter=" input.counter || false "
                        :rows=" input.rows || 1"
                        :label=" input.label || '' "
                        :rules=" input.rules || [] "
                    ></v-textarea>
                    <v-select v-if="input.type === 'select'"
                        v-model="value[input.value]"
                        :label="input.label"
                        :items="input.items"
                        :rules="input.rules"
                        @input="input.change ? $store.dispatch(`${input.change}`, value[input.value]) : null"
                        :disabled="input.disabled ? input.disabled : false"
                    ></v-select>
                </div>
                
                <v-alert v-show="$store.state.dialog.alert.show" :type="$store.state.dialog.alert.type" class="my-2">
                    {{ $store.state.dialog.alert.text }}
                </v-alert>
                <v-row justify="end">
                    <v-col cols='4' sm='3'>
                        <v-btn color="error" @click="close">Cancel</v-btn>
                    </v-col>
                    <v-col cols='4' sm='3'>
                        <v-btn 
                            color="primary" 
                            @click="submit(value)" 
                            :disabled="!validForm"
                            :loading="$store.state.dialog.loading"
                            >
                            Save
                        </v-btn>
                    </v-col>
                </v-row>
            </v-form>
        </v-card-text>
        </v-card>
    </v-dialog>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
    name: "contactForm",
    data() {
        return {
            validForm: false,
            value: {},
            form: {},
        }
    },
    created() {
        this.form = this.defaultForm
    },
    computed: {
        ...mapGetters('dialog', ['dialogTitle', 'isEdit', 'statusDialog']),
        dialog:{
            get(){ 
                return this.$store.state.dialog.status[this.name]
            },
            set(val){ 
                this.$store.commit('dialog/CHANGE_DIALOG',  { name: this.name, value: val })
            }
        }
    },
    watch: {
        dialog (value) {
            // console.log(value);
            
            if(!value) {
                this.$refs.from.reset()
                this.$refs.from.resetValidation()
            }
            
            if(this.isEdit > -1){
                let item = this.$store.state.dialog.editItem
                // this.$store.dispatch('')
                Object.assign(this.value, item)
            }
            else {
                Object.assign(this.value, this.defaultValue)
            }
            // console.log(this.value);
            
            this.$store.commit('dialog/ALERT_CHANGE', { show: false })
        },
    },
    methods: {
        close () {
            this.$store.commit('dialog/CHANGE_DIALOG', { name: this.name, value:false })
        },
        submit(value) {
            const action = this.isEdit ? 'edit' : 'new'
            this.resValue({ action, value })
        },

    },
    props: ['name', 'loading', 'resValue', 'defaultValue', 'defaultForm']
}
</script>

<style>

</style>