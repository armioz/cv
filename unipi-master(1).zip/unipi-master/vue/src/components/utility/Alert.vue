<template>
    <v-alert 
        v-show="$store.state.dialog.alert.show" 
        :type="$store.state.dialog.alert.type"
        dense
        class="my-1"
        >
            {{ $store.state.dialog.alert.text }}
    </v-alert>
</template>

<script>
export default {
    name: 'alert'
}
</script>

<style>

</style>