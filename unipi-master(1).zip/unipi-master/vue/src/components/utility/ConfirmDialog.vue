<template>
  <v-row justify="center">
    <v-dialog v-model="show" persistent max-width="300px">
      <v-card>
        <v-card-title>{{title}}</v-card-title>
        <v-card-text class="pb-0">
          {{text}}
          <Alert></Alert>
        </v-card-text>
        
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn 
            v-show="btnCancel.value" 
            color="error darken-1" 
            @click="submit(false)"
            :disabled="btnCancel.disabled"
            >
              {{btnCancel.text}}
          </v-btn>
          <v-btn 
            v-show="btnConfirm.value" 
            color="primary darken-1" 
            @click="submit(true)" 
            :loading="loading"
            >
            {{btnConfirm.text}}
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<script>
import { mapState } from 'vuex';
import Alert from './Alert';
  export default {
    name: 'confirmDialog',
    components:{
      Alert
    },
    computed: {
      ...mapState('confirm', ['btnCancel', 'btnConfirm', 'title', 'text', 'loading']),
      show: {
            get: function () { return this.$store.state.confirm.showing},
            set: function (value) {
                this.$store.commit('confirm/CHANGE_DIALOG', {showing: value})
            }
        },
    },
    props: ['submit']
  }
</script>