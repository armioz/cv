<template>
    <v-app-bar
        app
        color="primary"
        dark
        >
    <v-app-bar-nav-icon @click="DRAWER(true)"></v-app-bar-nav-icon>
    <div @click="$router.push('/')" class="d-flex align-center mr-5">
        <h1>UniPi</h1> 
    </div>
    <v-spacer></v-spacer>
    <div class="d-flex align-center mr-3">
        <span>{{ getUsername }}</span>
    </div>
    <v-btn
        target="_blank"
        @click="$router.push('/logout')"
        text
    >
        <span class="mr-2">Logout</span>
    </v-btn>
    </v-app-bar>
</template>

<script>
import { mapGetters, mapMutations } from "vuex";

export default {
    name: 'MyNavbar',
    computed: {
        ...mapGetters('auth', ['getUsername'])
    },
    methods: {
        ...mapMutations('layout', ['DRAWER'])
    },
}
</script>
