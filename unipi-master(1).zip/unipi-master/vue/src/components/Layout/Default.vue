<template>
    <div v-if="isLoggedIn">
        <MyNavbar></MyNavbar>
        <Navdrawer></Navdrawer>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
    components: {
        MyNavbar: () => import('./MyNavbar'),
        Navdrawer: () => import('./NavDrawer')
    },
    computed: {
        ...mapGetters('auth', ['isLoggedIn'])
    },
}
</script>

<style>

</style>