<template>
    <v-navigation-drawer
        v-model="drawer"
        fixed
        temporary
        class="grey darken-2"
        >
        <v-list dense nav >
            <div v-for="(link, i) in links" :key="i">
            <v-list-item  route :to="link.route" v-if="role === 'user' && !link.onlyAdmin">
                <v-list-item-icon>
                <v-icon class="white--text">{{ link.icon }}</v-icon>
                </v-list-item-icon>
                <v-list-item-content>
                <v-list-item-title class="white--text body-1">{{ link.text }}</v-list-item-title>
                </v-list-item-content>
            </v-list-item>
            <v-list-item  route :to="link.route" v-else-if="role === 'admin'">
                <v-list-item-icon>
                <v-icon class="white--text">{{ link.icon }}</v-icon>
                </v-list-item-icon>
                <v-list-item-content>
                <v-list-item-title class="white--text body-1">{{ link.text }}</v-list-item-title>
                </v-list-item-content>
            </v-list-item>
            </div>
        </v-list>
        </v-navigation-drawer>
</template>

<script>
import { mapGetters } from "vuex";

export default {
    name: 'navdrawer',
    computed: {
        ...mapGetters({
            links: 'layout/getLinks',
            role: 'auth/getUserRole'
        }),
        drawer: {
            get(){ return this.$store.state.layout.drawer },
            set(status){ this.$store.commit('layout/DRAWER', status) }
        }
    },
}
</script>

<style>

</style>