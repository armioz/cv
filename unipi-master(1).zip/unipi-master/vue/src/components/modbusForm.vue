<template>
    <v-dialog v-model="dialog" max-width="500px">
        <template v-slot:activator="{ on }">
            <v-btn color="primary" dark class="mb-2" v-on="on">New Item</v-btn>
        </template>
        <v-card>
        <v-card-title>
            <span class="headline">{{ formTitle }}</span>
        </v-card-title>
        <v-card-text>
            <v-form v-model="validForm" ref="modbusForm">
                <div v-for="input in fromData" :key="input.label">
                    <v-select v-if="input.type == 'select'"
                        v-model="formValues[input.value]"
                        :label="input.label"
                        :items="input.items"
                        :rules="input.rules"
                        :change="input.change ? changeSelected(input.change) : null"
                        :disabled="input.disabled ? input.disabled : false"
                        :required="input.required ? input.required : true"
                    ></v-select>
                    <v-text-field v-if="input.type == 'text'"
                        v-model="formValues[input.value]"
                        :label="input.label"
                        :rules="input.rules"
                        :disabled="input.disabled ? input.disabled : false"
                    ></v-text-field>
                    <v-text-field v-if="input.type == 'number'"
                        v-model="formValues[input.value]"
                        :label="input.label"
                        :rules="input.rules"
                        :min="input.min"
                        :max="input.max"
                        :step="input.step ? input.step : null"
                        :disabled="input.disabled ? input.disabled : false"
                        :type="input.type"
                    ></v-text-field>
                </div>
                <v-row justify="end">
                    <v-col cols='3'>
                        <v-btn color="error" @click="close">Cancel</v-btn>
                    </v-col>
                    <v-col cols='3'>
                        <v-btn color="primary" @click="save">Save</v-btn>
                    </v-col>
                </v-row>
            </v-form>
        </v-card-text>
        </v-card>
    </v-dialog>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'

export default {
    name: "modbusForm",
    data() {
        return {
            formValues: {
                ip_address: null,
                port: null,
                unitid: null,
                valvePosition: null,
                powerKW: null,
                Temp1C: null,
                Temp2C: null,
                Temp1W: null
            },
            validForm: true,
        }
    },
    computed: {
        ...mapState('modbus', ['fromData', 'editIndex']),
        ...mapGetters('modbus', ['formTitle']),
        dialog: {
            get: function () { return this.$store.state.modbus.dialog},
            set: function (val) {
                this.$store.commit('modbus/CHANGE_DIALOG', val)
            }
        },
    },
    watch: {
        dialog (val) {
            const state = this.$store.state.modbus
            // console.log(state.editIndex);
            if( val && state.editIndex > -1){
                this.formValues = state.editItem
            }
            else {
                val || this.close()
            }
        },
    },
    methods: {
        ...mapActions('modbus', ['saveData', 'updateData']),
        changeSelected (name) {
            if(name === 'ip' && this.formValues.ip_address) {
                this.changeIp()
            }
        },
        changeIp () {
                const ip = this.$store.state.modbus.items.find((item) => {
                    return item.ip_address === this.formValues.ip_address
                })
                this.formValues.port = ip.port
                this.formValues.unitid = ip.unitid
        },
        close () {
            this.dialog = false
            // console.log("close dialog");
            this.$store.commit('modbus/CLOSEDIALOG')
            this.$refs.modbusForm.reset()
            this.$refs.modbusForm.resetValidation()
        },
        save () {
            if(this.$refs.modbusForm.validate()){
                const data = this.convertDataToCreate(this.formValues)
                // console.log(this.editIndex , data);
                
                if(this.editIndex === -1) this.saveData(data)
                else this.updateData(data)
            }
        },
        convertDataToCreate (data) {
            return {
                ip_address: data.ip_address,
                port: data.port,
                unitid: data.unitid,
                valvePosition: data.valvePosition,
                powerKW: data.powerKW *100,
                Temp1C: data.Temp1C *100,
                Temp1K: (data.Temp1C + 273) *100,
                Temp2C: data.Temp2C *100,
                Temp2K: (data.Temp2C + 273) *100,
                Temp1W: data.Temp1W *100
            }
        }
        
    },
}
</script>

<style>

</style>
/*
    this.$refs.modbusForm.reset();
    this.$refs.modbusForm.resetValidation();
*/