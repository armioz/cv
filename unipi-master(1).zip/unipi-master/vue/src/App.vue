<template>
  <v-app>
    <MyHeader/>
    <v-content>
      <router-view></router-view>
    </v-content>
  </v-app>
</template>

<script>
export default {
  name: 'App',
  components: {
    MyHeader: () => import('./components/Layout/Default'),
  },
};
</script>
