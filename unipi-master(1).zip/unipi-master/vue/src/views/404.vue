<template>
    <div id="home">
        <v-container grid-list-xl>
        <h1>404 not Found Page </h1>
        </v-container>
    </div>
</template>

<script>
export default {
    name: "notFoundPage",
};
</script>

<style></style>
