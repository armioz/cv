<template>
    <v-container>
        <v-row justify="center">
            <v-col cols="8" md="6">
                <v-card>
                    <v-card-title primary-title>
                        <div>
                            <h3 class="headline mb-0">Login</h3>
                        </div>
                    </v-card-title>
                    <v-card-text>
                        <template>
                            <v-form v-model="valid" ref="form">
                                <v-text-field
                                    label="Uesrname"
                                    v-model="username"
                                    :rules="rules.username"
                                    :counter="25"
                                    required
                                ></v-text-field>
                                <v-text-field
                                    label="password"
                                    v-model="password"
                                    :rules="rules.password"
                                    :counter="25"
                                    :type="showPassword ? 'text' : 'password'"
                                    :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                                    @click:append="showPassword = !showPassword"
                                    required
                                ></v-text-field>
                                <v-alert v-show="logingErr" type="error">
                                    username or password is not match
                                </v-alert>
                                <v-btn
                                    class="primary"
                                    @click="login"
                                    :disabled="!valid"
                                    :loading="saving"
                                >
                                    Login
                                </v-btn>
                            </v-form>
                        </template>
                    </v-card-text>
                    <v-card-actions>
                    </v-card-actions>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>

export default {
    data: () => ({
        showPassword: false,
        valid: false,
        logingErr: false,
        saving: false,
        username: "",
        password: "",
        rules: {
            username: [
                v => !!v || "Username is required", 
                v => (v && v.length <= 25) || "Username must be less than 25 characters"
            ],
            password: [
                v => !!v || "Password is required", 
                v => (v && v.length <= 25) || "Password must be less than 25 characters"
            ]
        }
    }),
    computed: {

    },
    methods: {
        async login(){
            //form validation
            this.$refs.form.validate()
            this.saving = true
            this.logingErr = false
            // console.log(this.username, this.password)
            const success = await this.$store.dispatch('auth/retrieveToken', { username: this.username, password: this.password})
            if(!success) {
                this.logingErr = true 
            }            
            else {
                console.log("Login success");
                this.$router.push('/')
            }
            this.saving = false
            // console.log(loggingIn);
        }
    }
}
</script>

<style>

</style>