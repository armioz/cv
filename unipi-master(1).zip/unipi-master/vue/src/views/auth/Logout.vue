<template>
    <v-container grid-list-xs>
        
    </v-container>
</template>

<script>
export default {
    name: "login",
    created() {
        this.$store.dispatch("auth/destroyToken")
        this.$router.push("/login")
    },
}
</script>

<style>

</style>