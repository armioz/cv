<template>
    <div id="valuecontrol">
        <v-container grid-list-xl>
            <v-row>
                <v-col cols="12" sm="4" v-for="(value) in values" :key="value.id"> 
                    <v-card class="">
                        <v-card-title class="grey darken-3">
                            <span class=" white--text text-center">Value {{value.id}}</span> 
                        </v-card-title>
                        <v-list class="pa-0 text-center">
                            <v-list-item dense class="grey darken-2 ">
                                <v-list-item-content class="py-0">
                                    <v-list-item-title class=" white--text body-1">Status: {{value.status}}</v-list-item-title>
                                </v-list-item-content>
                            </v-list-item>
                            <v-list-item dense class="grey darken-2">
                                <v-list-item-content class="py-0">
                                    <v-list-item-title class=" white--text body-1">Temp 1: {{value.temp1}} C</v-list-item-title>
                                </v-list-item-content>
                            </v-list-item>
                            <v-list-item dense class="grey darken-2">
                                <v-list-item-content class="py-1">
                                    <v-list-item-title class=" white--text body-1">Temp 2: {{value.temp1}} C</v-list-item-title>
                                </v-list-item-content>
                            </v-list-item>
                        </v-list>
                        <v-card-actions class="grey darken-2">
                            <v-row>
                                <v-col>
                                    <v-btn block color="primary" dark @click="sendCommand(value, 2)">Start</v-btn>
                                </v-col>
                                <v-col>
                                    <v-btn block color="error" dark @click="sendCommand(value, 1)">Stop</v-btn>
                                </v-col>
                            </v-row>
                        </v-card-actions>
                    </v-card>
                </v-col>
            </v-row>
        </v-container>
    </div>
</template>

<script>
import axios from "axios";

export default {
    name: "valuecontrol",
    data() {
        return{
            values:[
                {    
                    id: 1,
                    status: "run",
                    temp1: 25,
                    temp2: 24,
                    uid: 1,
                    ip: '192.168.1.49',
                    port: '502',
                },
                {    
                    id: 2,
                    status: "run",
                    temp1: 25,
                    temp2: 24,
                }
            ]  
        }
    },
    methods: {
        sendCommand(value, codeToCommand) { 
            let data = {
                uid: 1,
                ip: "192.168.1.49",
                port: "502",
                codeControl: codeToCommand
            }
            axios.post('http://192.168.1.109:8000/testControl', data, { useCredentails: true })
            .then(response => {
                console.log(response);
            })
            .catch(e => {
                console.log(e);
            });
        },
    }
}
</script>

<style>

</style>