<template>
    <v-container grid-list-xs>
        <v-row>
            <v-col>
                <HeaderTable
                    name="Invoice Header"
                    :headers="headers"
                    :items="items"
                    >
                </HeaderTable>
            </v-col>
        </v-row>
        <v-row v-if="showDetial">
            <v-col>
                <DetialsTable
                    name="Invoice Detail"
                    :headers="detailHeader"
                    :items="detailItems"
                    >
                </DetialsTable>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import { mapState, mapActions } from 'vuex'

export default {
    name: 'invoice',
    components: {
        HeaderTable: () => import('@/components/Invoice/HeaderTable.vue'),
        DetialsTable: () => import('@/components/Invoice/DetailInvoice.vue'),
    },
    async created() {
        await this.getInvoice()
        await this.getContact()
        await this.getCatalog()
        await this.init_Input()
    },
    computed: {
        ...mapState('invoice', ['headers', 'items', 'detailHeader', 'detailItems', 'showDetial']),
    },
    methods: {
        ...mapActions({
            getInvoice: 'invoice/getInvoice',
            getContact: 'contact/getContact',
            init_Input: 'invoice/init_Input',
            getCatalog: 'catalog/getCatalog'
        })
    },
}
</script>

<style>

</style>