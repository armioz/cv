<template>
    <v-container grid-list-xs>
        <v-row>
            <v-col>
                <ContactTable
                    name="Contact"
                    :headers="headers"
                    :items="items"
                    >
                </ContactTable>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import { mapState, mapActions } from 'vuex'

export default {
    name: "contact",
    components: {
        ContactTable: () => import('@/components/Invoice/ContactTable.vue'),
    },
    created() {
        this.getContact()
    },
    computed: {
        ...mapState('contact', ['headers', 'items'])
    },
    methods: {
        ...mapActions('contact', ['getContact'])
    },
}
</script>

<style>

</style>
