<template>
    <v-container grid-list-xs>
        <v-row>
            <v-col>
                <CatalogTable
                    name="Catalog"
                    :headers="headers"
                    :items="items"
                    >
                </CatalogTable>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import { mapState, mapActions } from 'vuex'

export default {
    name: "contact",
    components: {
        CatalogTable: () => import('@/components/Invoice/CatalogTable.vue'),
    },
    created() {
        this.getCatalog()
    },
    computed: {
        ...mapState('catalog', ['headers', 'items'])
    },
    methods: {
        ...mapActions('catalog', ['getCatalog'])
    },
}
</script>

<style>

</style>
