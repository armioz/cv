<template>
    <v-container grid-list-xs>
        <v-row>
            <v-col>
                <TableUser
                    name="User"
                    :headers="headers"
                    :items="items"
                    >
                </TableUser>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <LogsTable
                    name="Logs"
                    :headers="logsHeader"
                    :items="logs"
                    >
                </LogsTable>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import { mapState, mapActions } from 'vuex'

export default {
    name: "user",
    components: {
        TableUser: () => import('../components/User/Table'),
        LogsTable: () => import('../components/User/LogsTable')
    },
    created() {
        this.getUser();
    },
    computed: {
        ...mapState('user', ['headers', 'items', 'logsHeader', 'logs'])
    },
    methods: {
        ...mapActions('user', ['getUser'])
    },
}
</script>

<style>

</style>
