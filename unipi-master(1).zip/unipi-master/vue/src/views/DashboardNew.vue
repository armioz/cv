<template>
<v-container grid-list-xs id="dashboardnew">
    <v-row>
        <v-col>   
            <v-data-table
                :headers="headers"
                :items="filteredItem"
                :sort-by.sync="options.sortBy"
                :sort-desc.sync="options.sortDesc"
                :items-per-page="options.itemsPerPage"
                @update:options="updateSort"
                :search="search"
                class="elevation-1"
                >
                <template v-slot:top>
                    <v-toolbar flat color="white">
                        <v-toolbar-title class="headline font-weight-bold">Dashboard</v-toolbar-title>
                        <v-divider class="mx-4" inset vertical></v-divider>
                        <v-spacer></v-spacer>
                        <modbusForm></modbusForm>
                    </v-toolbar>
                    <v-text-field
                        solo 
                        v-model="search" 
                        label="Search" 
                        class="mx-5" 
                        hide-details
                    >
                        <template v-slot:append-outer>
                            <v-menu offset-y allow-overflow>
                                <template v-slot:activator="{ on }">
                                    <v-btn
                                    color="primary"
                                    dark
                                    v-on="on"
                                    >
                                        <v-icon >mdi-plus</v-icon>
                                    </v-btn>
                                </template>
                                <v-list>
                                    <div v-for="(col) in headers" :key="col.text">
                                        <v-btn 
                                            text
                                            small 
                                            block 
                                            v-if="enable.indexOf(col.value) == -1 ? true : false" 
                                            class="text-left"
                                            @click="ENABLE_COL_SEARCH(col.value)"
                                            >
                                            <v-icon left>mdi-menu-right</v-icon>{{col.text}}
                                            <v-spacer></v-spacer>
                                        </v-btn>
                                    </div>
                                </v-list>
                            </v-menu>   
                        </template>
                    </v-text-field>
                    <v-row v-for="(text, i) in enable" :key="i" class="mt-2 mx-5" >
                        <v-col cols=12 md=6 class="pa-0">
                            <v-text-field
                                solo
                                dense
                                :label="text"
                                v-model="searchCol[text]"
                                hide-details
                            >
                                <template v-slot:prepend>
                                    <v-btn 
                                        text
                                        small 
                                        block 
                                        @click="DELETE_COL_SEARCH(text)"
                                        >
                                        <v-icon left>mdi-minus</v-icon>{{text}}
                                    </v-btn>
                                </template>
                            </v-text-field> 
                        </v-col>
                        <v-spacer></v-spacer>
                    </v-row>
                    

                </template>
                <template v-slot:body="{ items }">
                    <tbody class="mt-5">
                        <tr v-for="item in items" :key="item.id" :style="items.indexOf(item) % 2 ?  '' : 'background: #BDBDBD'" >
                            <td>{{ item.id }}</td>
                            <td>{{ item.ip_address }}</td>
                            <td>{{ item.port }}</td>
                            <td>{{ item.unitid }}</td>
                            <td>{{ item.valvePosition }}</td>
                            <td>{{ item.powerKW }}</td>
                            <td>{{ item.Temp1C }}</td>
                            <td>{{ item.Temp2C }}</td>
                            <td>{{ item.timeStamp }}</td>
                            <td> 
                                <v-icon small class="mr-2" @click="EDIT_ITEM(item)">
                                    mdi-pencil
                                </v-icon>
                                <v-icon small @click="deleteConfirm(item)">
                                    mdi-delete
                                </v-icon>
                            </td>
                        </tr>
                    </tbody>
                </template>
            </v-data-table>
        </v-col>
    </v-row>
</v-container>
</template>

<script>
import { mapState, mapActions, mapMutations } from 'vuex'

export default {
    name: "dashboardnew",
    beforeCreate: function () {
        this.$options.components.modbusForm = require('../components/modbusForm').default
    },
    component: {
        modbusForm: () => import('../components/modbusForm')
    },
    created() {
        this.getModbus();
    },
    computed: {
        ...mapState('modbus', ['headers', 'items', 'searchCol', 'enable', 'options']),
        search: {
            get: function(){ return this.$store.state.modbus.search},
            set: function(value){ this.$store.commit('modbus/SEARCH_ALL', value) }
        },
        filteredItem() {
            const fileld = this.enable.filter(t => this.searchCol[t].length > 0)
            
            return this.items.filter(ele => {
                return fileld.every(t => {return this.searchCol[t].includes(ele[t])})
            })
        }
    },
    methods: {
        ...mapActions('modbus', ['getModbus', 'editItem', 'deleteItem']),
        ...mapMutations('modbus', ['EDIT_ITEM', 'ENABLE_COL_SEARCH', 'DELETE_COL_SEARCH', 'UPDATE_OPTIONS']),
        async deleteConfirm(item) {
            const { value } = await this.$swal.fire({
                title: 'Are you sure',
                text: `you want to delete item ${item.id} ?`,
                icon: 'warning',
                showCancelButton: true,
                cancelButtonColor: '#E53935',
                confirmButtonColor: '#43A047',
                confirmButtonText: 'Yes, delete it!',
                reverseButtons: true
            })
            
            if(value){
                const deleted = await this.deleteItem(item)

                if(deleted){
                    this.$swal.fire({
                        title: 'Deleted!',
                        text: 'Your item has been deleted.',
                        icon: 'success',
                        confirmButtonColor: '#43A047',
                    })
                }
                else {
                    this.$swal.fire({
                        title: 'Can not Deleted!',
                        text: 'Your item has not been deleted.',
                        icon: 'error',
                        confirmButtonColor: '#43A047',
                        confirmButtonText: 'Yes, delete it!',
                    })
                }
            }
            // console.log(value);
            
            // this.deleteItem(item)
        },
        updateSort (val) {
            // console.log(val);
            this.UPDATE_OPTIONS(val)
        }
    },
}
</script>

<style>

</style>
