<template>
  <div id="home">
    <v-container grid-list-xl>
      <h1>Home</h1>
    </v-container>
  </div>
</template>

<script>
export default {
  name: "home"
}
</script>

<style>

</style>