import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '../store/store'
Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    name: 'login',
    component: () => import('../views/auth/Login.vue' /* webpackChunkName: "login" */),
    meta: {
      requiresVisitor: true,
    }
  },
  {
    path: '/logout',
    name: 'logout',
    component: () => import('../views/auth/Logout.vue' /* webpackChunkName: "logout" */),
    meta: { requiresAuth: true }
  },
  {
    path: '/',
    name: 'home',
    ccomponent: () => import('../views/Home.vue' /* webpackChunkName: "home" */),
    meta: { requiresAuth: true }
  },
  {
      path: '/dashboardnew',
      name: 'dashboardnew',
      component: () => import('../views/DashboardNew.vue' /* webpackChunkName: "dashboardnew" */),
      meta: { requiresAuth: true }
  },
  {
      path: '/user',
      name: 'user',
      component: () => import('../views/User.vue' /* webpackChunkName: "user" */),
      meta: { requiresAuth: true }
  },
  {
    path: '/invoice',
    name: 'invoice',
    component: () => import('../views/Invoice/Invoice.vue' /* webpackChunkName: "contact" */),
    meta: { requiresAuth: true }
  },
  {
    path: '/contact',
    name: 'contact',
    component: () => import('../views/Invoice/Contact.vue' /* webpackChunkName: "contact" */),
    meta: { requiresAuth: true }
  },
  {
    path: '/catalog',
    name: 'catalog',
    component: () => import('../views/Invoice/Catalog.vue' /* webpackChunkName: "contact" */),
    meta: { requiresAuth: true }
  },
  {
    path: '/valuecontrol',
    name: 'valuecontrol',
    component: () => import('../views/ValueControl.vue' /* webpackChunkName: "valuecontrol" */),
    meta: { requiresAuth: true }
  },
  {
    path: '*',
    name: 'notFoundPage',
    component: () => import('../views/404.vue' /* webpackChunkName: "notFoundPage" */),
    meta: { requiresAuth: true }
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
  const isLoggedIn = store.getters["auth/isLoggedIn"]
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth);

  if(requiresAuth && !isLoggedIn){
      next({path: '/login'})
  }
  else{
    next()
  }
})


export default router
