import http from "@/plugins/http-common";

export default {
    namespaced: true,
    state: {
        headers: [
            { text: 'id', value: 'id' },
            { text: 'username', value: 'username'},
            { text: 'role', value: 'role'},
            { text: 'Actions', value: 'actions', sortable: false},
        ],
        items: [],
        logsHeader: [
            { text: 'Id', value: 'id' },
            { text: 'Username', value: 'username'},
            { text: 'Time', value: 'time'},
        ],
        logs: []
    },
    getters: {
        formTitle(state) {
            return state.editIndex > -1 ? 'Edit' : 'New'
        }
    },
    mutations: {
        EDIT_ITEM (state, item) {
            // console.log( item);
            state.editIndex = state.items.indexOf(item)
            state.editItem = Object.assign({}, item)
        },
        INTI_USER(state, users) {
            state.items = users
        },
        ADD_NEW_USER (state, user) {
            state.items.push(user)
            // console.log(state, user);
        },
        UPDATED(state, {index, value}) {
            Object.assign(state.items[index], {
                id: state.items[index].id,
                username: value.username,
                role: value.role,
            })
        },
        DELETE (state, user) {
            state.items.splice(state.items.indexOf(user), 1)
        },
        INIT_LOGS(state, data){
            // console.log(data);
            state.logs = data.logs.map(v => {
                return {
                    id: v.id,
                    username: data.username,
                    time: v.time
                }
            })
            // console.log(state.logs);
            
        }
    },
    actions: {
        async getLogs ({commit}, user) {
            try {
                //GET request form /modbus
                const res = await http.get(`/user/logs/${user.id}`)
                // //Commit data and user to mutation 
                commit('INIT_LOGS', {username: user.username, logs: res.data})
            } catch (err) {
                return err
            }
        },
        async getUser ({commit}) {
            try {
                //GET request form /modbus
                const res = await http.get("/user")
                // //Commit data and user to mutation 
                commit('INTI_USER', res.data)
            } catch (err) {
                return err
            }
        },
        async register({commit}, user) {
            // console.log('new User', user);
            try {
                const regis = await http.post('/user', user)
                commit('ADD_NEW_USER', regis.data)
                return  {success: true, text: "Registration completed"}
            } catch (error) {
                return {success: false, text: "Username already exists"}
            }     
        },
        async update({commit, state}, {index, value}) {
            // console.log(commit,index, value);
            let id = state.items[index].id
            try {
                const updated = await http.put(`/user/${id}`, value)
                if(!updated) return {success: false, text: "Can not update"}
                // console.log(updated);
                commit('UPDATED', {index, value})
                return {success: true, text: "Update success"}
            }
            catch (err){
                return {success: false, text: "Can not update"}
            }
        },
        async delete({commit}, user) {
            try {
                const deleted = await http.delete(`/user/${user.id}`)
                if(!deleted) return {success: false, text: "Can not delete"}
                commit('DELETE', user)
                return {success: true, text: "Delete success"}
            } catch (err) {
                return {success: false, text: "Can not delete"}
            }
        }
    },

}