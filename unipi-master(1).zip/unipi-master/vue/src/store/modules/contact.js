import http from "@/plugins/http-common";

export default {
    namespaced: true,
    state: {
        headers: [
            { text: 'id', value: 'id' },
            { text: 'Customer Name', value: 'customer_name'},
            { text: 'Address', value: 'address'},
            { text: 'Actions', value: 'actions', sortable: false},
        ],
        items: [],
        form: {
            customerName: {
                label: "Customer Name",
                value: 'customer_name',
                rules : [
                    v => !!v || "Customer Name is required", 
                ],
                type: 'text',
            }, 
            address: {
                label: "Address",
                value: 'address',
                rules : [
                    v => !!v || "Address is required", 
                ],
                rows: 3,
                type: 'textarea',
            }, 
        },
        valueDefault: {
            customer_name: "",
            address: "",
        },
        
    },
    getters: {
        formTitle(state) {
            return state.editIndex > -1 ? 'Edit' : 'New'
        },
    },
    mutations: {
        INTI_CONTACTS(state, contacts) {
            state.items = contacts
        },
        ADD_NEW_ITEM(state, user) {
            state.items.push(user)
            // console.log(state, user);
        },
        UPDATED(state, {index, value}) {
            // console.log(index, value);
            Object.assign(state.items[index], value)
        },
        DELETE (state, user) {
            state.items.splice(state.items.indexOf(user), 1)
        },
    },
    actions: {
        async delete({commit}, contact) {
            try {
                const deleted = await http.delete(`/contact/${contact.id}`)
                if(!deleted) return {success: false, text: "Can not delete"}
                commit('DELETE', contact)
                return {success: true, text: "Delete success"}
            } catch (err) {
                return {success: false, text: "Can not delete"}
            }
        },
        async create({commit}, contact) {
            // console.log('new User', user);
            try {
                const regis = await http.post('/contact', contact)
                commit('ADD_NEW_ITEM', regis.data)
                return  {success: true, text: "Create new contact completed"}
            } catch (error) {
                return {success: false, text: "Contact can not create"}
            }     
        },
        async getContact ({commit}) {
            try {
                const res = await http.get("/contact")
                commit('INTI_CONTACTS', res.data)
            } catch (err) {
                return err
            }
        },
        async update({commit, state}, {index, value}) {
            // console.log(commit,index, value);
            let id = state.items[index].id
            
            try {
                const updated = await http.put(`/contact/${id}`, format(value))
                // console.log(updated);
                if(!updated) return {success: false, text: "Can not update"}

                commit('UPDATED', { index, value })
                return {success: true, text: "Update success"}
            }
            catch (err){
                return {success: false, text: "Can not update"}
            }
        },
    },

}

const format= (data) => {
    return {
        customer_name: data.customer_name,
        address: data.address,
    }
}