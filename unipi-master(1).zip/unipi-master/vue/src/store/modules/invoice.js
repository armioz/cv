import http from "@/plugins/http-common";

export default {
    namespaced: true,
    state: {
        showDetial: false,
        headers: [
            { text: 'id', value: 'invoiceId' },
            { text: 'Customer Name', value: 'customer_name'},
            { text: 'Address', value: 'address'},
            { text: 'status', value: 'status'},
            { text: 'total', value: 'total'},
            { text: 'Actions', value: 'actions', sortable: false},
        ],
        items: [],
        detailHeader: [
            { text: 'name', value: 'name'},
            { text: 'price', value: 'price'},
            { text: 'quantity', value: 'quantity'},
            { text: 'total'},
            { text: 'Actions', value: 'actions', sortable: false},
        ],
        detailItems: [],
        form: {
            customer_name: {
                label: "Customer Name",
                value: 'customer_name',
                items: [],
                rules : [
                    v => !!v || "Customer Name is required", 
                ],
                change: 'invoice/customerNameChange',
                type: 'select',
            },
            address: {
                label: "Address",
                value: 'address',
                items: [],
                rules : [
                    v => !!v || "Address is required", 
                ],
                type: 'select',
            },
            status: {
                label: "Status",
                value: "status",
                items: ['Paid', 'Unpaid', 'Open'],
                rules : [
                    v => !!v || "Status is required", 
                ],
                type: 'select',
            }
        },
        valueDefault: {
            customer_name: "",
            address: "",
            items: ""
        },
        formItem: {
            name: {
                label: "Item name",
                value: 'name',
                items: [],
                rules : [
                    v => !!v || "Item name is required", 
                ],
                type: 'select',
            },
            quantity: {
                label: "Quantity",
                value: 'quantity',
                rules : [
                    v => !!v || "Quantity is required", 
                    v => (v > 0) || "Quantity is required",
                ],
                type: 'number',
            },
        },
        valueDefaultItem: {
            name: "",
            quantity: "",
        },
        invoiceSelect: -1
    },
    getters: {
        formTitle(state) {
            return state.editIndex > -1 ? 'Edit' : 'New'
        }
    },
    mutations: {
        SET_ADDRESS ( state, value) {
            state.form.address.items = value
        },
        SET_CUS_NAME( state, value ) {
            state.form.customer_name.items = value
        },
        INTI_INVOICE(state, invoices) {
            state.items = invoices
        },
        ADD_NEW_ITEM(state, user) {
            state.items.push(user)
            // console.log(state, user);
        },
        UPDATED(state, {index, value}) {
            // console.log(index, value);
            Object.assign(state.items[index], value)
        },
        DELETE (state, user) {
            state.items.splice(state.items.indexOf(user), 1)
        },
        DELETEITEM (state, user) {
            state.detailItems.splice(state.detailItems.indexOf(user), 1)
        },
        SET_DETIAL ( state, {show, value, index}) {
            state.detailItems = value
            // console.log(state.detailItems);
            state.invoiceSelect = index
            state.showDetial = show
        },
        SET_CATA_ITEM ( state, items) {
            state.formItem.name.items = items.map( v => v.name)
        },
        ADD_NEW_ITEMDETAIL(state, user) {
            state.detailItems.push(user)
        },
        UPDATED_ITEM (state, {index, value}) {
            Object.assign(state.detailItems[index], value)
        }
    },
    actions: {
        async updateItem({ commit, state, rootState }, {index, value}) {
            let id = state.detailItems[index].id
            let sendData = {
                invoiceId: state.invoiceSelect,
                quantity: value.quantity,
                catalogId: rootState.catalog.items.find( v=> v.name === value.name).id
            }
            try {
                const updated = await http.put(`/invoice/item/${id}`, sendData)
                if(!updated) return {success: false, text: "Can not update"}
                let saveDATA = {
                    id: id,
                    quantity: sendData.quantity,
                    catalogId: sendData.catalogId,
                    invoiceId: sendData.invoiceId,
                    name: value.name,
                    price: value.price ,
                }
                commit('UPDATED_ITEM', {index, value: saveDATA})
                return {success: true, text: "Update success"}
            }
            catch (err){
                return {success: false, text: "Can not update"}
            }
        },
        async createItem({ commit, rootState, state}, data) {
            // console.log(findCatalogID(rootState.catalog.items, data), data, {commit});
            let sendData = {
                invoiceId: state.invoiceSelect,
                quantity: data.quantity,
                catalogId: findCatalogID(rootState.catalog.items, data)
            }
            
            try {
                const res = await http.post(`/invoice/item`, sendData)
                // console.log(res);
                let saveDATA = {
                    id: res.data.id,
                    quantity: res.data.quantity,
                    catalogId: res.data.catalogId,
                    invoiceId: res.data.invoiceId,
                    name: data.name,
                    price: rootState.catalog.items.find(v => v.name === data.name).price ,
                }
                commit('ADD_NEW_ITEMDETAIL', saveDATA)
                return  {success: true, text: "Create new invoice completed"}
            } catch (error) {
                return {success: false, text: "Invoice can not create"}
            }     
        },
        async deleteItem ({commit}, item) {
            try {
                const deleted = await http.delete(`/invoice/item/${item.id}`)
                if(!deleted) return {success: false, text: "Can not delete"}
                commit('DELETEITEM', item)
                return {success: true, text: "Delete success"}
            } catch (err) {
                return {success: false, text: "Can not delete"}
            }
        },
        async getInvoiceItem ({commit}, item) {
            // console.log({ show, item}, {commit});
            try {
                const res = await http.get(`/invoice/item/${item.invoiceId}`)
                commit('SET_DETIAL', {show: true, value: res.data, index: item.invoiceId})
                // console.log(res.data);
            } catch (err) {
                return err
            }
        },
        init_Input({commit, rootState}) {
            // console.log(rootState);
            let contact = rootState.contact.items
            let cusName = contact.map( v => v.customer_name )
            let address = contact.map( v => v.address )
            commit('SET_CUS_NAME', cusName)
            commit('SET_ADDRESS', address)

            let catalog = rootState.catalog.items
            console.log(catalog);
            
            commit('SET_CATA_ITEM', catalog)
        },
        customerNameChange({ commit, rootState }, value){
            // console.log(value);
            let newAddress
            if (value) {
                newAddress = rootState.contact.items.filter(v => v.customer_name === value).map(v => v.address)
            }
            else {
                newAddress = rootState.contact.items.map(v => v.address)
            }
            commit('SET_ADDRESS', newAddress)
        },
        async delete({commit}, data) {
            try {
                const deleted = await http.delete(`/invoice/${data.invoiceId}`)
                if(!deleted) return {success: false, text: "Can not delete"}
                commit('DELETE', data)
                return {success: true, text: "Delete success"}
            } catch (err) {
                return {success: false, text: "Can not delete"}
            }
        },
        async create({commit, rootState}, data) {
            // console.log('new', data, commit);
            // console.log(findContactID(rootState.contact.items, data));
            try {
                let sendData = {
                    contactId: findContactID(rootState.contact.items, data),
                    status: data.status,
                    total: 0
                }
                const res = await http.post('/invoice', sendData)
                
                let saveDATA = {
                    invoiceId: res.data.id,
                    status: data.status,
                    total: 0,
                    contactId: sendData.contactId,
                    customer_name: data.customer_name,
                    address: data.address
                }
                commit('ADD_NEW_ITEM', saveDATA)
                return  {success: true, text: "Create new invoice completed"}
            } catch (error) {
                return {success: false, text: "Invoice can not create"}
            }     
        },
        async getInvoice ({commit}) {
            try {
                const res = await http.get("/invoice")
                commit('INTI_INVOICE', res.data)
                // console.log(res.data);
            } catch (err) {
                return err
            }
        },
        async update({ commit, state, rootState}, {index, value}) {
            // console.log(index);
            
            let id = state.items[index].invoiceId
            // console.log( id );

            let sendData = {
                contactId: findContactID(rootState.contact.items, value),
                status: value.status,
                total: value.total
            }
            // console.log(sendData);
            try {
                const updated = await http.put(`/invoice/${id}`, sendData)
                // console.log(updated);
                if(!updated) return {success: false, text: "Can not update"}

                commit('UPDATED', {index, value})
                return {success: true, text: "Update success"}
            }
            catch (err){
                return {success: false, text: "Can not update"}
            }
        },
    },

}

const findContactID = (data, key) => {
    return data.find(v => v.customer_name === key.customer_name && v.address === key.address).id
}
const findCatalogID = (data, key) => {
    return data.find(v => v.name === key.name).id
}