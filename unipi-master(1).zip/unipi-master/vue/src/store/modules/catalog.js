import http from "@/plugins/http-common";

export default {
    namespaced: true,
    state: {
        headers: [
            { text: 'id', value: 'id' },
            { text: 'name', value: 'name'},
            { text: 'price', value: 'price'},
            { text: 'Actions', value: 'actions', sortable: false},
        ],
        items: [],
        form: {
            name: {
                label: "Name",
                value: 'name',
                rules : [
                    v => !!v || "Name is required",
                ],
                type: 'text',
            }, 
            price: {
                label: "Price",
                value: 'price',
                rules : [
                    v => !!v || "Price is required", 
                ],
                type: 'number',
            }, 
        },
        valueDefault: {
            name: '',
            price: ''
        }
    },
    getters: {
        formTitle(state) {
            return state.editIndex > -1 ? 'Edit' : 'New'
        }
    },
    mutations: {
        INTI_CONTACTS(state, contacts) {
            state.items = contacts
        },
        ADD_NEW_ITEM(state, user) {
            state.items.push(user)
            // console.log(state, user);
        },
        UPDATED(state, {index, value}) {
            // console.log(index, value);
            Object.assign(state.items[index], value)
        },
        DELETE (state, user) {
            state.items.splice(state.items.indexOf(user), 1)
        },
    },
    actions: {
        async delete({commit}, contact) {
            try {
                const deleted = await http.delete(`/catalog/${contact.id}`)
                if(!deleted) return {success: false, text: "Can not delete"}
                commit('DELETE', contact)
                return {success: true, text: "Delete success"}
            } catch (err) {
                return {success: false, text: "Can not delete"}
            }
        },
        async create({commit}, data) {
            // console.log('new User', user);
            try {
                const regis = await http.post('/catalog', data)
                commit('ADD_NEW_ITEM', regis.data)
                return  {success: true, text: "Create new catalog completed"}
            } catch (error) {
                return {success: false, text: "Catalog can not create"}
            }     
        },
        async getCatalog ({commit}) {
            try {
                const res = await http.get("/catalog")
                commit('INTI_CONTACTS', res.data)
            } catch (err) {
                return err
            }
        },
        async update({commit, state}, {index, value}) {
            // console.log(commit,index, value);
            let id = state.items[index].id
            
            try {
                const updated = await http.put(`/catalog/${id}`, format(value))
                // console.log(updated);
                if(!updated) return {success: false, text: "Can not update"}

                commit('UPDATED', {index, value})
                return {success: true, text: "Update success"}
            }
            catch (err){
                return {success: false, text: "Can not update"}
            }
        },
    },

}

const format= (data) => {
    return {
        name: data.name,
        price: data.price
    }
}