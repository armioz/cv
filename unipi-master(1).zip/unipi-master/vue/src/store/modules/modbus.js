import http from "../../plugins/http-common";
import moment from 'moment';

export default {
    namespaced: true,
    state: {
        search: '',
        dialog: false,
        searchCol: {
            id: '',
            ip_address: '',
            port: '',
            unitid: '',
            valvePosition: '',
            powerKW:'',
            Temp1C: '',
            Temp2C: '',
            timeStamp: '',
        },
        enable: [],
        headers: [
            { text: 'id', value: 'id' },
            { text: 'ip_address', value: 'ip_address'},
            { text: 'port', value: 'port'},
            { text: 'unitid', value: 'unitid'},
            { text: 'valvePosition', value: 'valvePosition'},
            { text: 'powerKW', value: 'powerKW'},
            { text: 'Temp1C', value: 'Temp1C'},
            { text: 'Temp2C', value: 'Temp2C'},
            { text: 'timeStamp', value: 'timeStamp'},
            { text: 'Actions', value: 'actions', sortable: false},
        ],
        items: [],
        options: localStorage.getItem('TABLE_MODBUS_OPTIONS') ? JSON.parse(localStorage.getItem('TABLE_MODBUS_OPTIONS'))  :
        {
            sortBy: 'id',
            sortDesc: false,
            itemsPerPage: 5,
        },
        editIndex: -1,
        editItem: {},
        fromData: {
            ip_address: {
                label: "IP address",
                value: 'ip_address',
                items: [""],
                rules: [v => !!v || 'required'],
                type: 'select',
                change: 'ip'
            }, 
            port: {
                value: 'port',
                label: "Port",
                rules: [v => !!v || 'required'],
                type: "text",
                disabled: true,
            },
            unitid: {
                value: 'unitid',
                label: "Unit id",
                items: [],
                rules: [v => !!v || 'required'],
                type: "text",
                disabled: true,
            },
            valvePosition: {
                value: 'valvePosition',
                label: "Valve position",
                min: 0,
                max: 100,
                step: .1,
                rules: [ 
                    v => !!v || 'required',
                    v => v <= 100 || 'Maximun value is 100',
                    v => v >= 0 || 'Mininumun value is 0'
                ],
                type: "number",
            },
            powerKW: {
                value: 'powerKW',
                label: "Power KW",
                min: 0,
                max: 10000,
                step: .1,
                rules: [ 
                    v => !!v || 'required',
                    v => v <= 10000 || 'Maximun value is 10000',
                    v => v >= 0 || 'Mininumun value is 0'
                ],
                type: "number",
            },
            Temp1C: {
                value: 'Temp1C',
                label: "Temp1C",
                min: -1000,
                max: 1000,
                step: .1,
                rules: [ 
                    v => !!v || 'required',
                    v => v <= 1000 || 'Maximun value is 1000',
                    v => v >= -1000 || 'Mininumun value is -1000'
                ],
                type: "number",
            },
            Temp2C: {
                value: 'Temp2C',
                label: "Temp2C",
                min: -1000,
                max: 1000,
                step: .1,
                rules: [ 
                    v => !!v || 'required',
                    v => v <= 1000 || 'Maximun value is 1000',
                    v => v >= -1000 || 'Mininumun value is -1000'
                ],
                type: "number",
            },
            Temp1W: {
                value: 'Temp1W',
                label: "Temp1W",
                min: -1000,
                max: 1000,
                step: .1,
                rules: [ 
                    v => !!v || 'required',
                    v => v <= 1000 || 'Maximun value is 1000',
                    v => v >= -1000 || 'Mininumun value is -1000'
                ],
                type: "number",
            },
        },

    },
    getters: {
        formTitle (state) {
            return state.editIndex === -1 ? 'New Item' : 'Edit Item'
        },
    },
    mutations: {
        SEARCH_COLUMN (state, value) {
            state.searchColumn = value
        },
        SEARCH_ALL (state, value) {
            state.search = value
        },
        INTI_MODBUS (state, data) {
            //SET new item and re data
            state.items = data.map((e, index) => {
                return {
                    'index': index,
                    'id': e.id,
                    'ip_address': e.ip_address ,
                    'port': e.port ,
                    'unitid': e.unitid ,
                    'timeStamp':  moment(e.timeStamp).format('MM/DD/YYYY hh:mm'),
                    'valvePosition': e.valvePosition ,
                    'powerKW': e.powerKW/100 ,
                    'Temp1C': e.Temp1C/100 ,
                    'Temp2C': e.Temp2C/100 ,
                    'Temp1W': e.Temp1W/100 ,
                }
            })
            //SET Ip to select form
            state.fromData.ip_address.items = [...new Set(state.items.map(item => item.ip_address))]
        },
        CLOSEDIALOG (state) {
            state.editItem  = Object.assign({}, {})
            state.editIndex = -1
        },
        EDIT_ITEM (state, item) {
            // console.log( item);
            state.editIndex = state.items.indexOf(item)
            state.editItem = Object.assign({}, item)
            state.dialog = true
        },
        CHANGE_DIALOG (state, val) {
            state.dialog = val
        },
        CREATE_MODBUS (state, e) {
            console.log(state, e);

            state.items.push({
                'index': state.items.length + 1,
                'id': e.id,
                'ip_address': e.ip_address ,
                'port': e.port ,
                'unitid': e.unitid ,
                'timeStamp':  moment(e.timeStamp).format('MM/DD/YYYY hh:mm'),
                'valvePosition': e.valvePosition ,
                'powerKW': e.powerKW/100 ,
                'Temp1C': e.Temp1C/100 ,
                'Temp2C': e.Temp2C/100 ,
                'Temp1W': e.Temp1W/100 ,
            })
        },
        UPDATE_MODBUS (state, e) {
            console.log(state, e);
            Object.assign(state.items[state.editIndex], 
                {
                    'index': state.editIndex,
                    'id': state.editItem.id,
                    'ip_address': e.ip_address ,
                    'port': e.port ,
                    'unitid': e.unitid ,
                    'timeStamp':  moment(e.timeStamp).format('MM/DD/YYYY hh:mm'),
                    'valvePosition': e.valvePosition ,
                    'powerKW': e.powerKW/100 ,
                    'Temp1C': e.Temp1C/100 ,
                    'Temp2C': e.Temp2C/100 ,
                    'Temp1W': e.Temp1W/100 ,
                }
            )
        },
        DELETE_MODBUS (state, index) {
            state.items.splice(index, 1)
        },
        ENABLE_COL_SEARCH (state, name) {
            // console.log(state.enable.indexOf(name));
            state.enable.push(name)
            
        },
        DELETE_COL_SEARCH (state, name) {
            // console.log(state.enable.indexOf(name));
            state.searchCol[name] = ''
            state.enable.splice(state.enable.indexOf(name), 1)
        },
        UPDATE_OPTIONS (state, val) {
            localStorage.setItem('TABLE_MODBUS_OPTIONS', JSON.stringify(val))
            state.options = val
        }
    },
    actions: {
        async getModbus (context) {
            try {
                //GET request form /modbus
                const res = await http.get("/modbus")
                // //Commit data and user to mutation 
                context.commit('INTI_MODBUS', res.data)
            } catch (err) {
                return err
            }
        },
        async saveData (context, item) {
            try {
                const res = await http.post('/modbus', item)
                context.commit('CREATE_MODBUS', res.data)
                // console.log(res)
            } catch (err) {
                return err
            }
            // console.log(this.state.modbus.editIndex, item);
            
        },
        async updateData  (context, item) {
            try {
                const res = await http.put(`/modbus/${context.state.editItem.id}`, item)
                context.commit('UPDATE_MODBUS', item)
                console.log("res", res)
                return res
            } catch (err) {
                console.log(err);
                return err
            }
            // console.log(this.state.modbus.editIndex, item);
        },
        async deleteItem (context, item) {
            try {
                await http.delete(`/modbus/${item.id}`)
                context.commit('DELETE_MODBUS', context.state.items.indexOf(item))
                return true
            } catch (err) {
                return false
            }
        },
    },
}

/*
valvePosition: {
    min: 0,
    max: 100,
    step: .1,
    rules: [
        v => v >= 0 || true,
    ]
},
powerKW: {
    min: 0,
    step: .1,
    rules: [
        v => v >= 0 || true,
    ]
},
Temp1C: {
    step: .1,
    rules: [
        v => v || true,
    ]
},
Temp2C: {
    step: .1,
    rules: [
        v => v || true,
    ]
},
Temp1W: {
    step: .1,
    rules: [
        v => v || true,
    ]
}*/