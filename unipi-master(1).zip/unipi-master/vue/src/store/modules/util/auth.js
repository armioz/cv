import http from '../../../plugins/http-common'

export default {
    namespaced: true,
    state: {
        user: JSON.parse(localStorage.getItem('USER')) || null,
        token: localStorage.getItem('AUTH_TOKEN') || null,
    },
    getters: {
        isLoggedIn(state) {
            return state.token ? true : false
        },
        getUser (state) {
            return state.user
        },
        getUsername (state) {
            return state.user.username
        },
        getUserRole (state) {
            return state.user.role
        }
    },
    actions: {
        destroyToken(context){
            context.commit('destroyToken')
        },
        async retrieveToken(context, credentials) {
            // console.log(context, credentials);
            try {
                const res = await http.post("/auth/login", {username: credentials.username, password: credentials.password})

                const data = {
                    token: res.data.token,
                    user: res.data.user
                }
            
                //Commit token and user to mutation
                context.commit('retrieveUser', data)
                // console.log(jwt.decode(token));
                return true
            } catch (err) {
                return false
            }
        },
    },
    mutations: {
        retrieveUser(state, data){
            //Set token username to localstoreage
            localStorage.setItem('AUTH_TOKEN', data.token)
            localStorage.setItem('USER', JSON.stringify(data.user))
            //Set to state
            state.token = data.token
            state.user = data.user
            // console.log(data);
        },
        destroyToken(state) {
            localStorage.removeItem('AUTH_TOKEN')
            localStorage.removeItem('USER')
            localStorage.removeItem('TABLE_MODBUS_OPTIONS')
            state.token = null
            state.user = null
        },
    }
}