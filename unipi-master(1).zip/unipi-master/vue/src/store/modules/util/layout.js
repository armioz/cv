
export default {
    namespaced: true,
    state: {
        drawer: false,
        links: [
            { icon: 'mdi-account', text: 'User Manegement', route: '/user', onlyAdmin: true},
            { icon: 'dashboard', text: 'Dashboard New', route: '/dashboardnew'},
            { icon: 'dashboard', text: 'Value Control', route: '/valuecontrol'},
            { icon: 'mdi-content-paste', text: 'Invoice', route: '/invoice'},
            { icon: 'mdi-account-multiple-outline', text: 'Contact', route: '/contact'},
            { icon: 'mdi-grid', text: 'Catalog', route: '/catalog'},
        ],
    },
    getters: {
        getLinks (state) {
            return state.links
        }
    },
    actions: {
    },
    mutations: {
        DRAWER (state, status) {
            state.drawer = status
        }
    }
}