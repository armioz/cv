//Store dialog status and state

export default {
    namespaced: true,
    state: {
        name: '',
        status: {
            'invoice header': false,
            'invoice detail': false,
            'user': false
        },
        editIndex: -1,
        editItem: {},
        alert : {
            type: 'success',
            text: '',
            show: false
        },
        loading: false,
    },
    getters: {
        dialogTitle(state) {
            // console.log(state.editIndex)
            return state.editIndex > -1 ? 'Edit' : 'New'
        },
        isEdit(state) {
            return state.editIndex > -1
        },
    },
    mutations: {
        LOADING (state, value) {
            state.loading = value
        },
        CHANGE_DIALOG (state, { name, value }) {
            console.log(name);
            
            state.status[name.toLowerCase()] = value
            if(value === false) {
                state.editIndex = -1
                state.editItem = {}
            }
        },
        EDIT_ITEM (state, value) {
            // console.log( value);
            state.editIndex = value.index
            state.editItem = Object.assign({}, value.item)
        },
        ALERT_CHANGE (state, value) {
            state.alert = value
        },
        SET_NAME( state, name ) {
            console.log(name);
            
            state.name = name
        }
    },
    actions: {
    }
}
