export default {
    namespaced: true,
    state: {
        title: "title",
        text: "text",
        showing: false,
        btnCancel: {
            value: true,
            text: "cancel",
            disabled: false
        },
        btnConfirm: {
            value: true,
            text: "Confirm"
        },
        loading: false
    },
    getters: {
    },
    mutations: {
        CHANGE_DIALOG(state, value) {
            // console.log(value);
            state.showing = value.showing
            state.title = value.title || 'title'
            state.text = value.text || 'text'
            state.confirmed = false
            state.loading = false
            state.btnCancel.disabled = false
            state.confirmed = null
        },
        LOADING(state) {
            // console.log("Loding");
            state.btnCancel.disabled = true
            state.loading = true
        }
    },
    actions: {
        confirming({commit}){
            commit('CHANGE_DIALOG', {showing: true})
        }
    }
}
