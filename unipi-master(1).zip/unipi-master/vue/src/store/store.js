import Vue from 'vue'
import Vuex from 'vuex'

import auth from './modules/util/auth'
import layout from './modules/util/layout'
import dialog from './modules/util/dialog'
import confirm from './modules/util/confirm'

import user from './modules/user'
import modbus from './modules/modbus'
import contact from './modules/contact'
import catalog from './modules/catalog'
import invoice from './modules/invoice'

Vue.use(Vuex)

export default new Vuex.Store({
    modules: {
        layout,
        user,
        modbus,
        auth,
        dialog,
        confirm,
        contact,
        catalog,
        invoice
    }
})
