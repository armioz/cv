import connectServer
from random import random, randrange

class modbus():
    def __init__(self, id, ip, port):
        self.id = id
        self.port = port
        self.ip = ip
        self.data = {
            "ip_address": ip,
            "port": port,
            "unitid": id,
            "valvePosition": randrange(0, 100),
            "powerKW": randrange(0, 100),
            "Temp1C": randrange(1000),
            "Temp1K": randrange(1000),
            "Temp2C": randrange(1000),
            "Temp2K": randrange(1000),
            "Temp1W": randrange(1000)
        }

    def run(self):
        post = connectServer.sendPost('/modbus', self.data)
        print(self.id, post)

if __name__ == "__main__":
    unit1 = modbus('1', '192.168.1.1', '502')
    unit2 = modbus('2', '192.168.1.109', '49')
    for i in range(500):
        unit1.run()
        unit2.run()
    