import requests

def sendPost(API, DATA, ):
    URL = "http://localhost:5000/api"
    HEADER = {
        "Content-Type": "application/json",
    }   
    return requests.post(URL + API, json=DATA)
